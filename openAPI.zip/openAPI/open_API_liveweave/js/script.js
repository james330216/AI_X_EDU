// Write JavaScript here 
function process()
{
  $.ajax({
    url: "https://dapi.kakao.com/v2/translation/translate",
    type: "POST",
    contentType: "application/x-www-form-urlencoded",
    headers: {"Authorization": "KakaoAK aaa"},
    data: $("#transExForm").serialize(),
    success: function(data)
    {
      $("#result_translation").val(data.translated_text);
    },
    error: function(jqXHR, textStatus, errorThrown)
    {
      var errorMsg = "ready Status: ";
      errorMsg += jqXHR.readyState + "\n";
      errorMsg = "Status: ";  
      errorMsg += jqXHR.Status + "\n";
      errorMsg = "Status Text: ";  
      errorMsg += jqXHR.statusText + "\n";
      alert(errorMsg);
    }
    })
}
