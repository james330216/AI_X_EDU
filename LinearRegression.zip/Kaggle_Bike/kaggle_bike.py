import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# 그래프에서 격자로 숫자 범위가 눈에 잘 띄도록 ggplot 스타일을 사용
plt.style.use('ggplot')

# 그래프에서 마이너스 폰트 깨지는 문제에 대한 대처
mpl.rcParams['axes.unicode_minus'] = False

# table 컬럼이 다 보이지 않음 (속성을 None)으로 변경
pd.set_option('display.max_columns', None)

# parse_dates: 해당 컬럼을 date-time 형식으로 읽어드림
train = pd.read_csv("bike-sharing-demand/train.csv", parse_dates=["datetime"])
print("학습 데이터 형식: ", train.shape)

# train.columns
# train.dtypes
# 컬럼에 대한 데이터 타입에 대한 보다 상세한 정보를 알 수 있음
train.info()

# windspeed가 0인 값은 측정된 데이터가 없을 때 0으로 들어가 있다고 생각.
print(train.head(15)) # print(train.head(5))

# 컬럼 중 온도에 해당하는 통계치 확인
print(train.temp.describe())
#
# 결측치 확인 (NaN)
print(train.isnull().sum()) # 결측치인 값을 조회해 그 갯수를 반환

# DateTime을 년,월, 일, 시로 분할
train["year"] = train["datetime"].dt.year
train["month"] = train["datetime"].dt.month
train["day"] = train["datetime"].dt.day
train["hour"] = train["datetime"].dt.hour
train["minute"] = train["datetime"].dt.minute
train["second"] = train["datetime"].dt.second
print(train.shape) # (10886, 12) ==> (10866, 18)

# Subplot 2x3 (표를 2x3으로 만들고 그림 삽입하는 느낌.)
figure, ((ax1,ax2,ax3), (ax4,ax5,ax6)) = plt.subplots(nrows=2, ncols=3)
figure.set_size_inches(18,8)

# 년, 월, 일, 시에 따른 대여량 그래프로 확인 (데이터 시각화)
sns.barplot(data=train, x="year", y="count", ax=ax1)
sns.barplot(data=train, x="month", y="count", ax=ax2)
sns.barplot(data=train, x="day", y="count", ax=ax3)
sns.barplot(data=train, x="hour", y="count", ax=ax4)
sns.barplot(data=train, x="minute", y="count", ax=ax5)
sns.barplot(data=train, x="second", y="count", ax=ax6)

ax1.set(ylabel='Count',title="year_cnt") #연도별 대여량
ax2.set(xlabel='month',title="month_cnt") # 월별 대여량
ax3.set(xlabel='day', title="day_cnt") # 일별 대여량
ax4.set(xlabel='hour', title="hour_cnt") # 시간별 대여량

plt.show()

# 요일 추가
train["dayofweek"] = train["datetime"].dt.dayofweek
print(train.shape)
print(train["dayofweek"].value_counts())


fig,(ax1,ax2,ax3,ax4,ax5)= plt.subplots(nrows=5)
fig.set_size_inches(18,25)

# x축은 시간, y축은 대여량 ==> 주말, 요일, 날씨 등에 따른 시간대별 대여량 데이터 시각화
sns.pointplot(data=train, x="hour", y="count", ax=ax1)
sns.pointplot(data=train, x="hour", y="count", hue="workingday", ax=ax2)
sns.pointplot(data=train, x="hour", y="count", hue="dayofweek", ax=ax3)
sns.pointplot(data=train, x="hour", y="count", hue="weather", ax=ax4)
sns.pointplot(data=train, x="hour", y="count", hue="season", ax=ax5)

plt.show()

# 상관관계 그래프
corrMatt = train[["temp", "atemp", "casual", "registered", "humidity", "windspeed", "count"]]
corrMatt = corrMatt.corr()
print(corrMatt)

mask = np.array(corrMatt)
mask[np.tril_indices_from(mask)] = False
fig, ax = plt.subplots()
fig.set_size_inches(20, 10)
sns.heatmap(corrMatt, mask=mask,vmax=.8, square=True,annot=True)

plt.show()

# 산점도, 온도, 풍속, 습도에 따른 대여량 산점도 (풍속의 경우, 0에 데이터가 많이 편중되어 있음을 확인 가능)
fig,(ax1,ax2,ax3) = plt.subplots(ncols=3)
fig.set_size_inches(12, 5)
sns.regplot(x="temp", y="count", data=train,ax=ax1)
sns.regplot(x="windspeed", y="count", data=train,ax=ax2)
sns.regplot(x="humidity", y="count", data=train,ax=ax3)

plt.show()

# trainWithoutOutliers
trainWithoutOutliers = train[np.abs(train["count"] - train["count"].mean()) <= (3*train["count"].std())]
print(train.shape)
# 표준편차에서 멀리 떨어져 있는 데이터 삭제 (약 150개 정도 삭제)
print(trainWithoutOutliers.shape)

# count값의 데이터 분포도를 파악
figure, (ax1, ax2) = plt.subplots(ncols=2)
figure.set_size_inches(12, 10)

sns.distplot(train["count"], ax=ax1)
# outlier 제거 및 count 변수에 log화
sns.distplot(np.log(trainWithoutOutliers["count"]), ax=ax2)

plt.show()