import tensorflow as tf
import numpy as np

data = np.loadtxt('sell_house.txt', unpack=False, dtype='float32')

x_test_data = data[-5:, 1:-1]
y_test_data = data[-5:, [-1]]
x_train = data[0:-5, 1:-1]
y_train = data[0:-5, [-1]]

tf.model = tf.keras.Sequential()

tf.model.add(tf.keras.layers.Dense(units=1, input_dim=11))  # input_dim=11 gives multi-variable regression
tf.model.add(tf.keras.layers.Activation('linear'))  # this line can be omitted, as linear activation is default

tf.model.compile(loss='mse', optimizer=tf.keras.optimizers.SGD(lr=1e-4))
tf.model.summary()
# history = tf.model.fit(x_train, y_train, epochs=20000)
history = tf.model.fit(x_train, y_train, epochs=10)

y_predict = tf.model.predict(x_test_data)
print(y_predict)